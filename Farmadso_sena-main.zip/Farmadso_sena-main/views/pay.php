<!--Id cliente paypal-->
<script src="https://www.paypal.com/sdk/js?client-id=AVWgpMk3r1AGWqSWCLInEmnNyB8mnUZqQtRrBN6NqEFZ7ycGeHiRT_oM_3_3M4NvsQEzJhLI5HX3EqHQ&currency=USD">
</script>

<!-- Contenedor paypal -->
<div id="paypal-button-container">
    <h2>Página de Pago Seguro por PayPal</h2>
    <img src="../assets/svg/Payment Information-amico.svg" alt="">

</div>